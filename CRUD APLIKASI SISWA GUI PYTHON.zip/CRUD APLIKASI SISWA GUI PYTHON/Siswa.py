from db import DBConnection as mydb

class Siswa:
    def __init__(self):
        self.__idsiswa=None
        self.__nisn=None
        self.__nama=None
        self.__jk=None
        self.__jurusan=None
        self.__info = None
        self.conn = None
        self.affected = None
        self.result = None
        
        
    @property
    def info(self):
        if(self.__info==None):
            return "NISN:" + self.__nisn + "\n" + "Nama:" + self.__nama + "\n" + "Jk" + self.__jk + "\n" + "Jurusan:" + self.__jurusan
        else:
            return self.__info
    
    @info.setter
    def info(self, value):
        self.__info = value

    @property
    def id(self):
        return self.__idsiswa

    @property
    def nisn(self):
        return self.__nisn

    @nisn.setter
    def nisn(self, value):
        self.__nisn = value

    @property
    def nama(self):
        return self.__nama

    @nama.setter
    def nama(self, value):
        self.__nama = value

    @property
    def jk(self):
        return self.__jk

    @jk.setter
    def jk(self, value):
        self.__jk = value

    @property
    def jurusan(self):
        return self.__jurusan

    @jurusan.setter
    def jurusan(self, value):
        self.__jurusan = value

    def simpan(self):
        self.conn = mydb()
        val = (self.__nisn, self.__nama, self.__jk, self.__jurusan)
        sql="INSERT INTO siswa (nisn, nama, jk, jurusan) VALUES " + str(val)
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected

    def update(self, idsiswa):
        self.conn = mydb()
        val = (self.__nisn, self.__nama, self.__jk, self.__jurusan, idsiswa)
        sql="UPDATE siswa SET nisn = %s, nama = %s, jk=%s, jurusan=%s WHERE idsiswa=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected

    def updateByNISN(self, nisn):
        self.conn = mydb()
        val = (self.__nama, self.__jk, self.__jurusan, nisn)
        sql="UPDATE siswa SET nama = %s, jk=%s, jurusan=%s WHERE nisn=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected        

    def delete(self, idsiswa):
        self.conn = mydb()
        sql="DELETE FROM siswa WHERE idsiswa='" + str(idsiswa) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected

    def deleteByNISN(self, nisn):
        self.conn = mydb()
        sql="DELETE FROM siswa WHERE nisn='" + str(nisn) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected

    def getByID(self, idsiswa):
        self.conn = mydb()
        sql="SELECT * FROM siswa WHERE idsiswa='" + str(idsiswa) + "'"
        self.result = self.conn.findOne(sql)
        self.__nisn = self.result[1]
        self.__nama = self.result[2]
        self.__jk = self.result[3]
        self.__jurusan = self.result[4]
        self.conn.disconnect
        return self.result

    def getByNISN(self, nisn):
        a=str(nisn)
        b=a.strip()
        self.conn = mydb()
        sql="SELECT * FROM siswa WHERE nisn='" + b + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__nisn = self.result[1]
            self.__nama = self.result[2]
            self.__jk = self.result[3]
            self.__jurusan = self.result[4]
            self.affected = self.conn.cursor.rowcount
        else:
            self.__nisn = ''
            self.__nama = ''
            self.__jk = ''
            self.__jurusan = ''
            self.affected = 0
        self.conn.disconnect
        return self.result

    def getAllData(self):
        self.conn = mydb()
        sql="SELECT * FROM siswa"
        self.result = self.conn.findAll(sql)
        return self.result
