from db import DBConnection as mydb

class Matapelajaran:
    def __init__(self):
        self.__idmp= None
        self.__kodemp= None
        self.__namamp= None
        self.__sks= None
        self.__jurusan= None
        self.__info = None
        self.conn = None
        self.affected = None
        self.result = None

    @property
    def info(self):
        if(self.__info==None):
            return "KodeMP:" + self.__kodemp + "\n" + "NamaMP:" + self.__namamp + "\n" + "SKS" + self.__sks + "\n" + "jurusan:" + self.__jurusan
        else:
            return self.__info

    @property
    def id(self):
        return self.__idmp
    
    @property
    def kodemp(self):
        return self.__kodemp

    @kodemp.setter
    def kodemp(self, value):
        self.__kodemp = value
    
    @property
    def namamp(self):
        return self.__namamp

    @namamp.setter
    def namamp(self, value):
        self.__namamp = value
    
    @property
    def sks(self):
        return self.__sks

    @sks.setter
    def sks(self, value):
        self.__sks = value
    
    @property
    def jurusan(self):
        return self.__jurusan

    @jurusan.setter
    def jurusan(self, value):
        self.__jurusan = value
        
    def simpan(self):
        self.conn = mydb()
        val = (self.__kodemp,self.__namamp,self.__sks,self.__jurusan)
        sql="INSERT INTO matapelajaran (kodemp,namamp,sks,jurusan) VALUES " + str(val) 
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected
        
    def update(self, idmp):
        self.conn = mydb()
        val = (self.__kodemp,self.__namamp,self.__sks,self.__jurusan, idmp)
        sql="UPDATE matapelajaran SET kodemp=%s, namamp=%s, sks=%s, jurusan=%s WHERE idmp=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
        
    def updateByKODEMP(self, kodemp):
        self.conn = mydb()
        val = (self.__kodemp,self.__namamp,self.__sks,self.__jurusan, kodemp)
        sql="UPDATE matapelajaran SET kodemp=%s, namamp=%s, sks=%s, jurusan=%s WHERE kodemp=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected
        
    def delete(self, idmp):
        self.conn = mydb()
        sql="DELETE FROM matapelajaran WHERE idmp='" + str(idmp) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
        
    def deleteByKODEMP(self, kodemp):
        self.conn = mydb()
        sql="DELETE FROM matapelajaran WHERE kodemp='" + str(kodemp) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected
        
    def getByID(self, id):
        self.conn = mydb()
        sql="SELECT * FROM matapelajaran WHERE idmp='" + str(id) + "'"
        self.result = self.conn.findOne(sql)
        self.__kodemp = self.result[1]                   
        self.__namamp = self.result[2]                   
        self.__sks = str(self.result[3])                   
        self.__jurusan = self.result[4]                   
        self.conn.disconnect
        return self.result
        
    def getByKODEMP(self, kodemp):
        a=str(kodemp)
        b=a.strip()
        self.conn = mydb()
        sql="SELECT * FROM matapelajaran WHERE kodemp='" + b + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__kodemp = self.result[1]                   
            self.__namamp = self.result[2]                   
            self.__sks = str(self.result[3])                   
            self.__jurusan = self.result[4]                   
            self.affected = self.conn.cursor.rowcount
        else:
            self.__kodemp = ''                  
            self.__namamp = ''                  
            self.__sks = ''                  
            self.__jurusan = ''                  
            self.affected = 0
            self.conn.disconnect
            return self.result

    def getAllData(self):
        self.conn = mydb()
        sql="SELECT * FROM matapelajaran"
        self.result = self.conn.findAll(sql)
        return self.result