from db import DBConnection as mydb

class Guru:

    def __init__(self):
        self.__idguru=None
        self.__nip=None
        self.__nama=None
        self.__jk=None
        self.__pelajaran=None
        self.__info = None
        self.conn = None
        self.affected = None
        self.result = None
        
        
    @property
    def info(self):
        if(self.__info==None):
            return "NIP:" + self.__nip + "\n" + "Nama:" + self.__nama + "\n" + "Jk" + self.__jk + "\n" + "Pelajaran:" + self.__pelajaran
        else:
            return self.__info
    
    @info.setter
    def info(self, value):
        self.__info = value

    @property
    def idguru(self):
        return self.__idguru

    @property
    def nip(self):
        return self.__nip

    @nip.setter
    def nip(self, value):
        self.__nip = value

    @property
    def nama(self):
        return self.__nama

    @nama.setter
    def nama(self, value):
        self.__nama = value

    @property
    def jk(self):
        return self.__jk

    @jk.setter
    def jk(self, value):
        self.__jk = value

    @property
    def pelajaran(self):
        return self.__pelajaran

    @pelajaran.setter
    def pelajaran(self, value):
        self.__pelajaran = value

    def simpan(self):
        self.conn = mydb()
        val = (self.__nip, self.__nama, self.__jk, self.__pelajaran)
        sql="INSERT INTO guru (nip, nama, jk, pelajaran) VALUES " + str(val)
        self.affected = self.conn.insert(sql)
        self.conn.disconnect
        return self.affected

    def update(self, idguru):
        self.conn = mydb()
        val = (self.__nip, self.__nama, self.__jk, self.__pelajaran, idguru)
        sql="UPDATE guru SET nip = %s, nama = %s, jk=%s, pelajaran=%s WHERE idguru=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected

    def updateByNIP(self, nip):
        self.conn = mydb()
        val = (self.__nama, self.__jk, self.__pelajaran, nip)
        sql="UPDATE guru SET nama = %s, jk=%s, pelajaran=%s WHERE nip=%s"
        self.affected = self.conn.update(sql, val)
        self.conn.disconnect
        return self.affected        

    def delete(self, idguru):
        self.conn = mydb()
        sql="DELETE FROM guru WHERE idguru='" + str(idguru) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected

    def deleteByNIP(self, nip):
        self.conn = mydb()
        sql="DELETE FROM guru WHERE nip='" + str(nip) + "'"
        self.affected = self.conn.delete(sql)
        self.conn.disconnect
        return self.affected

    def getByIDGURU(self, idguru):
        self.conn = mydb()
        sql="SELECT * FROM guru WHERE idguru='" + str(idguru) + "'"
        self.result = self.conn.findOne(sql)
        self.__nip = self.result[1]
        self.__nama = self.result[2]
        self.__jk = self.result[3]
        self.__pelajaran = self.result[4]
        self.conn.disconnect
        return self.result

    def getByNIP(self, nip):
        self.conn = mydb()
        sql="SELECT * FROM guru WHERE nip='" + str(nip) + "'"
        self.result = self.conn.findOne(sql)
        if(self.result!=None):
            self.__nip = self.result[1]
            self.__nama = self.result[2]
            self.__jk = self.result[3]
            self.__pelajaran = self.result[4]
            self.affected = self.conn.cursor.rowcount
        else:
            self.__nip = ''
            self.__nama = ''
            self.__jk = ''
            self.__pelajaran = ''
            self.affected = 0
        self.conn.disconnect
        return self.result

    def getAllData(self):
        self.conn = mydb()
        sql="SELECT * FROM guru"
        self.result = self.conn.findAll(sql)
        return self.result